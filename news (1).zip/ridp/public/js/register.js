document.getElementById('registerForm').addEventListener('submit', async (event) => {
    event.preventDefault(); // Prevent default form submission
    const name = event.target.name.value;
    const email = event.target.email.value;
    const password = event.target.password.value;

    const response = await fetch('/auth/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, email, password })
    });

    if (response.ok) {
        // Redirect to login page after successful registration
        window.location.href = '/login';
    } else {
        const result = await response.json();
        alert(result.message); // Display error message if registration fails
    }
});
