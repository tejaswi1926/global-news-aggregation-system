const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');
const path = require('path');
const dotenv = require('dotenv');
const connectDB = require('./config/db');
const authRoutes = require('./routes/auth');
const session = require('express-session');
const User = require('./models/User');

// Load environment variables
dotenv.config();
connectDB();

const app = express();
const port = process.env.PORT || 4000;

const API_KEY = process.env.API_KEY;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Initialize session middleware
app.use(session({
  secret: 'yourSecretKey',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false }
}));

// Serve static files from the 'public' folder
app.use(express.static(path.join(__dirname, 'public')));

// Authentication routes
app.use('/auth', authRoutes);

// Middleware to check if user is authenticated
function isAuthenticated(req, res, next) {
  if (req.session.user) {
    next();
  } else {
    res.redirect('/login');
  }
}

// Root route redirects to login page by default
app.get('/', (req, res) => {
  res.redirect('/login');
});

// Serve login page
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// Serve register page
app.get('/register', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'register.html'));
});

// Authenticate login
app.post('/auth/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (user && (await user.comparePassword(password))) {
      req.session.user = user;
      res.json({ success: true, message: 'Login successful' });
    } else {
      res.status(401).json({ success: false, message: 'Invalid credentials' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Register a new user
app.post('/auth/register', async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ message: 'Name, email, and password are required.' });
  }
  try {
    const newUser = new User({ name, email, password });
    await newUser.save();
    res.redirect('/login');
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Serve news page only if authenticated
app.get('/news', isAuthenticated, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'news.html'));
});

// News API route
app.get('/api/news', async (req, res) => {
  const { category = 'general', query = '' } = req.query;
  let url;

  if (query) {
    url = `http://api.mediastack.com/v1/news?access_key=${API_KEY}&countries=in&keywords=${encodeURIComponent(query)}`;
  } else {
    url = `http://api.mediastack.com/v1/news?access_key=${API_KEY}&countries=in&categories=${category}`;
  }

  try {
    const response = await fetch(url);
    const data = await response.json();
    
    // Debugging: Log the fetched data
    console.log('Fetched data:', data);

    if (!data || !data.data || data.data.length === 0) {
      return res.status(404).json({ error: 'No articles found' });
    }
    
    // Send back the articles array
    res.json(data.data); // Assuming articles are stored in 'data'
  } catch (error) {
    console.error('Error fetching news:', error);
    res.status(500).json({ error: 'Failed to fetch news' });
  }
});

// Logout route
app.post('/auth/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      return res.status(500).json({ message: 'Could not log out' });
    }
    res.redirect('/login');
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
